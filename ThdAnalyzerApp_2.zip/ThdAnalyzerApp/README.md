# THD Analyzer — App Android (companion per THD_v18_serial.ino)

App Android nativa (Kotlin) che comunica via **USB-OTG seriale** (nessun Bluetooth)
con l'ESP32 Audio Kit che esegue il firmware `THD_v18_serial.ino`.

## Come aprirla

1. Apri Android Studio (versione recente, es. 2024.x).
2. **File → Open** e seleziona questa cartella (`ThdAnalyzerApp`).
3. Lascia che Android Studio generi automaticamente il Gradle Wrapper mancante
   (te lo proporrà da solo al primo sync — clicca "OK"/"Sync Now").
4. Collega il telefono Android in modalità sviluppatore e premi Run ▶,
   oppure genera l'APK con **Build → Build Bundle(s)/APK(s) → Build APK(s)**.

## Come si collega alla scheda

Serve un **cavo/adattatore USB-OTG** (USB-C o micro-USB a seconda del telefono)
per collegare direttamente la porta USB dell'ESP32 Audio Kit al telefono.
Non serve alcun modulo Bluetooth aggiuntivo.

Chip USB-seriale già riconosciuti in `device_filter.xml`:
CP210x (Silicon Labs), CH340 (WCH), FTDI FT232, ESP32-S2/S3 nativo USB.
Se la tua board usa un altro chip, aggiungi il suo vendor/product ID nello stesso file
(la libreria `usb-serial-for-android` li supporta comunque anche senza il filtro,
basta collegare e premere "Connetti" nell'app).

## Cosa fa l'app

- **Connessione**: rileva il dispositivo USB seriale, chiede il permesso Android,
  apre la porta a 115200 baud / 8N1 (stessi parametri del firmware).
- **Lettura live**: fa il parsing delle righe `MEDIA(n) F:...Hz THD:...% THD+N:...%`
  che il firmware stampa continuamente durante l'acquisizione, e aggiorna
  THD%, THD+N% e frequenza a schermo.
- **Controllo remoto** (comandi seriali già supportati dal firmware v18):
  - `GAIN <0-8>` — step di guadagno PGA, 3 dB per step (causa riavvio ESP32,
    è una limitazione del firmware: la scrittura I2C del guadagno è affidabile
    solo appena dopo `kit.begin()`)
  - `NOISE <hz>` — soglia esclusione rumore, applicata immediatamente
  - `AVG <n>` — numero di medie, applicato immediatamente
  - `STATUS` — richiede lo stato corrente (stampato nel log)
- **Log seriale grezzo**: tutte le righe ricevute (incluse le diagnostiche
  `[DIAG]` e i messaggi di conferma comandi) sono visibili in fondo alla schermata.

## Limitazione nota

Il firmware attuale **non ha un comando seriale START/STOP acquisizione**:
è controllata solo dai due pulsanti fisici sulla board. Se vuoi anche questo
controllo dall'app, serve aggiungere un comando (es. `RUN` / `STOP`) dentro
`handleSerialCommands()` in `THD_v18_serial.ino` — non è incluso qui per non
toccare il firmware senza tua conferma esplicita.

## Struttura

```
app/src/main/java/com/simoz/thdanalyzer/MainActivity.kt   <- tutta la logica
app/src/main/res/layout/activity_main.xml                 <- UI
app/src/main/res/xml/device_filter.xml                    <- filtro USB
```
