package com.simoz.thdanalyzer

import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simoz.thdanalyzer.databinding.ActivitySettingsBinding

/**
 * Schermata impostazioni: Gain / Noise threshold / numero medie.
 * Invia i comandi tramite SerialManager, usando la connessione già
 * aperta da MainActivity (questa schermata non gestisce la connessione).
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private var gainStep = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBackToMain.setOnClickListener { finish() }

        binding.btnGainMinus.setOnClickListener {
            if (gainStep > 0) gainStep--
            updateGainLabel()
        }
        binding.btnGainPlus.setOnClickListener {
            if (gainStep < 8) gainStep++
            updateGainLabel()
        }
        binding.btnGainSend.setOnClickListener {
            if (sendCommand("GAIN $gainStep")) {
                Toast.makeText(this, "Comando inviato: la scheda si riavvierà", Toast.LENGTH_SHORT).show()
            }
        }
        updateGainLabel()

        binding.seekNoise.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.tvNoiseValue.text = "${progress * 5} Hz"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        binding.btnNoiseSend.setOnClickListener {
            val hz = binding.seekNoise.progress * 5
            if (sendCommand("NOISE $hz")) {
                Toast.makeText(this, "Soglia inviata: $hz Hz", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnAvgSend.setOnClickListener {
            val n = binding.etAvg.text.toString().toIntOrNull()
            if (n == null || n < 1) {
                Toast.makeText(this, "Inserisci un numero valido (1-100)", Toast.LENGTH_SHORT).show()
            } else if (sendCommand("AVG $n")) {
                Toast.makeText(this, "Medie impostate: $n", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateGainLabel() {
        binding.tvGainValue.text = "+${gainStep * 3} dB (step $gainStep)"
    }

    /** Ritorna true se l'invio è andato a buon fine (mostra un Toast se fallisce). */
    private fun sendCommand(cmd: String): Boolean {
        if (!SerialManager.isConnected()) {
            Toast.makeText(this, "Non connesso all'ESP32", Toast.LENGTH_SHORT).show()
            return false
        }
        val ok = SerialManager.sendCommand(cmd)
        if (!ok) Toast.makeText(this, "Errore invio comando", Toast.LENGTH_SHORT).show()
        return ok
    }
}
