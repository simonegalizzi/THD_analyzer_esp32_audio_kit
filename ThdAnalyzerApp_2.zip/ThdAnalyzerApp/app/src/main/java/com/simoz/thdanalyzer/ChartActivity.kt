package com.simoz.thdanalyzer

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.simoz.thdanalyzer.databinding.ActivityChartBinding

/**
 * Schermata grafico: mostra l'andamento di THD% e THD+N% nel tempo,
 * leggendo dal buffer condiviso ThdHistory (popolato da MainActivity
 * ogni volta che arriva una riga "MEDIA(...)" dalla seriale).
 */
class ChartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChartBinding
    private val handler = Handler(Looper.getMainLooper())
    private val refreshIntervalMs = 500L

    private val refreshRunnable = object : Runnable {
        override fun run() {
            val (thd, thdn) = ThdHistory.snapshot()
            binding.chartView.updateData(thd, thdn)
            handler.postDelayed(this, refreshIntervalMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBackToMain.setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        handler.post(refreshRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refreshRunnable)
    }
}
