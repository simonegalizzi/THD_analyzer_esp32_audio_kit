package com.simoz.thdanalyzer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.Locale

/**
 * Grafico a linee disegnato a mano su Canvas (nessuna libreria esterna).
 * Mostra THD% (verde) e THD+N% (rosso) sulle ultime N letture ricevute.
 */
class ThdChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var thdData: List<Float> = emptyList()
    private var thdnData: List<Float> = emptyList()

    private val thdLinePaint = Paint().apply {
        color = Color.parseColor("#00E5A0")
        strokeWidth = 5f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }
    private val thdnLinePaint = Paint().apply {
        color = Color.parseColor("#FF5252")
        strokeWidth = 5f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }
    private val axisPaint = Paint().apply {
        color = Color.parseColor("#606060")
        strokeWidth = 2f
        isAntiAlias = true
    }
    private val textPaint = Paint().apply {
        color = Color.parseColor("#A0A0A0")
        textSize = 30f
        isAntiAlias = true
    }

    fun updateData(thd: List<Float>, thdn: List<Float>) {
        thdData = thd
        thdnData = thdn
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val marginLeft = 100f
        val marginBottom = 50f
        val marginTop = 60f
        val marginRight = 20f

        // Assi
        canvas.drawLine(marginLeft, marginTop, marginLeft, h - marginBottom, axisPaint)
        canvas.drawLine(marginLeft, h - marginBottom, w - marginRight, h - marginBottom, axisPaint)

        // Legenda (sempre visibile)
        val thdLegendPaint = Paint(thdLinePaint).apply { style = Paint.Style.FILL }
        val thdnLegendPaint = Paint(thdnLinePaint).apply { style = Paint.Style.FILL }
        canvas.drawText("— THD%", marginLeft, marginTop - 30f, thdLegendPaint)
        canvas.drawText("— THD+N%", marginLeft + 200f, marginTop - 30f, thdnLegendPaint)

        if (thdData.size < 2) {
            canvas.drawText("In attesa di dati dall'ESP32...", marginLeft + 20f, h / 2f, textPaint)
            return
        }

        val maxVal = (thdData + thdnData).maxOrNull()?.coerceAtLeast(0.001f) ?: 1f
        val plotWidth = w - marginLeft - marginRight
        val plotHeight = h - marginTop - marginBottom

        fun drawSeries(data: List<Float>, paint: Paint) {
            if (data.size < 2) return
            val stepX = plotWidth / (data.size - 1)
            var prevX = marginLeft
            var prevY = h - marginBottom - (data[0] / maxVal) * plotHeight
            for (i in 1 until data.size) {
                val x = marginLeft + i * stepX
                val y = h - marginBottom - (data[i] / maxVal) * plotHeight
                canvas.drawLine(prevX, prevY, x, y, paint)
                prevX = x
                prevY = y
            }
        }

        drawSeries(thdData, thdLinePaint)
        drawSeries(thdnData, thdnLinePaint)

        // Etichette asse Y
        canvas.drawText(String.format(Locale.US, "%.3f%%", maxVal), 10f, marginTop + 10f, textPaint)
        canvas.drawText("0%", 10f, h - marginBottom, textPaint)

        // Ultimo valore THD in evidenza
        val lastThd = thdData.last()
        canvas.drawText(
            String.format(Locale.US, "ultimo: %.4f%%", lastThd),
            marginLeft, marginTop - 5f, textPaint
        )
    }
}
