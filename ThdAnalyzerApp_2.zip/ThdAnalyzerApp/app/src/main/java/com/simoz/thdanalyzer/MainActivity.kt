package com.simoz.thdanalyzer

import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simoz.thdanalyzer.databinding.ActivityMainBinding

/**
 * THD Analyzer - client Android per il firmware ESP32 "THD_v18_serial.ino".
 *
 * La connessione USB seriale vera e propria è gestita da SerialManager
 * (singleton indipendente dal ciclo di vita di questa Activity), così i dati
 * continuano ad arrivare anche quando si naviga su Settings o sul Grafico.
 * Questa Activity si limita a registrarsi sui callback di SerialManager per
 * aggiornare la UI e a innescare la connessione iniziale.
 *
 * NB: il firmware attuale non espone un comando seriale START/STOP:
 * l'acquisizione resta controllata dai pulsanti fisici sulla board.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        SerialManager.init(this)
        setupSerialCallbacks()
        setupUi()

        // Se l'app e' stata lanciata dall'aggancio automatico del dispositivo USB
        if (intent?.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE) != null) {
            attemptConnect()
        }
    }

    private fun setupSerialCallbacks() {
        SerialManager.onLine = { line -> log(line) }
        SerialManager.onReading = { freq, thd, thdn ->
            binding.tvThdValue.text = "THD: $thd %"
            binding.tvThdnValue.text = "THD+N: $thdn %"
            binding.tvFreqValue.text = "Freq: $freq Hz"
        }
        SerialManager.onConnectionChanged = { connected -> setConnected(connected) }

        // Se torniamo su questa schermata mentre si e' gia' connessi
        // (es. tornando da Settings), riallinea subito lo stato mostrato.
        setConnected(SerialManager.isConnected())
    }

    private fun setupUi() {
        binding.btnConnect.setOnClickListener { attemptConnect() }
        binding.btnStatus.setOnClickListener { SerialManager.sendCommand("STATUS") }

        binding.btnChart.setOnClickListener {
            startActivity(Intent(this, ChartActivity::class.java))
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun attemptConnect() {
        val found = SerialManager.connect()
        if (!found) {
            Toast.makeText(this, "Nessun dispositivo USB seriale trovato. Collega l'ESP32 via OTG.", Toast.LENGTH_LONG).show()
            log("Nessun driver USB seriale trovato.")
        }
    }

    private fun setConnected(connected: Boolean) {
        binding.tvConnectionStatus.text = if (connected) "Connesso" else "Non connesso"
        binding.btnConnect.text = if (connected) "Riconnetti" else "Connetti"
    }

    private fun log(text: String) {
        binding.tvLog.append("$text\n")
    }
}
