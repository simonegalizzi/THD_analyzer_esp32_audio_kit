package com.simoz.thdanalyzer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import java.io.IOException
import java.util.concurrent.Executors

/**
 * Gestisce la connessione USB seriale come singleton indipendente dal ciclo
 * di vita di qualunque Activity. Prima, MainActivity possedeva direttamente
 * la connessione: navigando su Settings/Chart, se il sistema metteva in
 * pausa (o terminava per risparmio memoria) MainActivity, la lettura dati
 * si fermava e il grafico restava vuoto. Ora la connessione resta viva
 * finché il processo dell'app esiste, indipendentemente da quale schermata
 * è in primo piano.
 *
 * Le Activity si registrano sui callback (onLine/onReading/onConnectionChanged)
 * per aggiornare la UI; il parsing e il popolamento di ThdHistory avvengono
 * qui, sempre, a prescindere da chi sta ascoltando in quel momento.
 */
object SerialManager {

    private const val ACTION_USB_PERMISSION = "com.simoz.thdanalyzer.USB_PERMISSION"
    private const val BAUD_RATE = 115200

    // Es: "MEDIA(4) F:1000.3Hz THD:0.0812% THD+N:0.1023%"
    private val MEDIA_REGEX = Regex(
        """MEDIA\((\d+)\)\s+F:([\d.]+)Hz\s+THD:([\d.]+)%\s+THD\+N:([\d.]+)%"""
    )

    private var appContext: Context? = null
    private var usbManager: UsbManager? = null
    private var serialPort: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val rxLineBuffer = StringBuilder()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var receiverRegistered = false

    /** Callback opzionali che le Activity possono assegnare per aggiornare la UI. */
    var onLine: ((String) -> Unit)? = null
    var onReading: ((freq: String, thd: String, thdn: String) -> Unit)? = null
    var onConnectionChanged: ((Boolean) -> Unit)? = null

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            val device: UsbDevice? = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            if (granted && device != null) {
                openDevice(device)
            } else {
                postLine("Permesso USB negato dall'utente.")
            }
        }
    }

    /** Da chiamare una volta, es. in Application.onCreate o nel onCreate di MainActivity. */
    fun init(context: Context) {
        if (appContext != null) return
        val ctx = context.applicationContext
        appContext = ctx
        usbManager = ctx.getSystemService(Context.USB_SERVICE) as UsbManager

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.registerReceiver(ctx, usbPermissionReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            ctx.registerReceiver(usbPermissionReceiver, filter)
        }
        receiverRegistered = true
    }

    fun isConnected(): Boolean = serialPort != null

    /** Ritorna false se non c'è nessun dispositivo USB seriale disponibile. */
    fun connect(): Boolean {
        val manager = usbManager ?: return false
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(manager)
        if (drivers.isEmpty()) return false

        val device = drivers[0].device
        if (manager.hasPermission(device)) {
            openDevice(device)
        } else {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val permissionIntent = PendingIntent.getBroadcast(appContext, 0, Intent(ACTION_USB_PERMISSION), flags)
            manager.requestPermission(device, permissionIntent)
        }
        return true
    }

    private fun openDevice(device: UsbDevice) {
        val manager = usbManager ?: return
        val driver = UsbSerialProber.getDefaultProber().findAllDrivers(manager)
            .firstOrNull { it.device == device } ?: return

        val connection = manager.openDevice(driver.device)
        if (connection == null) {
            postLine("Impossibile aprire la connessione USB (permesso mancante?).")
            return
        }

        val port = driver.ports[0]
        try {
            port.open(connection)
            port.setParameters(BAUD_RATE, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: IOException) {
            postLine("Errore apertura porta seriale: ${e.message}")
            return
        }

        serialPort = port
        ioManager = SerialInputOutputManager(port, object : SerialInputOutputManager.Listener {
            override fun onNewData(data: ByteArray) {
                handleIncomingBytes(data)
            }
            override fun onRunError(e: Exception) {
                postLine("Connessione persa: ${e.message}")
                serialPort = null
                postConnectionChanged(false)
            }
        })
        executor.submit(ioManager)

        postConnectionChanged(true)
        postLine("Connesso a ${driver.device.deviceName} @ $BAUD_RATE baud.")
        sendCommand("STATUS")
    }

    /** Ritorna true se l'invio è andato a buon fine. */
    fun sendCommand(cmd: String): Boolean {
        val port = serialPort ?: return false
        return try {
            port.write((cmd + "\n").toByteArray(Charsets.US_ASCII), 1000)
            postLine(">> $cmd")
            true
        } catch (e: IOException) {
            postLine("Errore invio comando: ${e.message}")
            false
        }
    }

    // ===================== Ricezione e parsing (sempre attivi) =====================

    private fun handleIncomingBytes(data: ByteArray) {
        synchronized(rxLineBuffer) {
            rxLineBuffer.append(String(data, Charsets.US_ASCII))
            var newlineIndex: Int
            while (rxLineBuffer.indexOf("\n").also { newlineIndex = it } >= 0) {
                val line = rxLineBuffer.substring(0, newlineIndex).trim('\r', '\n', ' ')
                rxLineBuffer.delete(0, newlineIndex + 1)
                if (line.isNotEmpty()) processLine(line)
            }
        }
    }

    private fun processLine(line: String) {
        val match = MEDIA_REGEX.find(line)
        if (match != null) {
            val (_, freq, thd, thdn) = match.destructured

            // Popola SEMPRE lo storico, indipendentemente da quale Activity è in primo piano.
            val thdFloat = thd.toFloatOrNull()
            val thdnFloat = thdn.toFloatOrNull()
            if (thdFloat != null && thdnFloat != null) {
                ThdHistory.addSample(thdFloat, thdnFloat)
            }
            postReading(freq, thd, thdn)
        }
        postLine(line)
    }

    // ===================== Callback su main thread =====================

    private fun postLine(line: String) {
        mainHandler.post { onLine?.invoke(line) }
    }

    private fun postReading(freq: String, thd: String, thdn: String) {
        mainHandler.post { onReading?.invoke(freq, thd, thdn) }
    }

    private fun postConnectionChanged(connected: Boolean) {
        mainHandler.post { onConnectionChanged?.invoke(connected) }
    }
}
