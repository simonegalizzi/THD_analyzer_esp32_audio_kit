package com.simoz.thdanalyzer

/**
 * Buffer in memoria (non persistente) delle ultime letture THD/THD+N,
 * popolato da MainActivity ogni volta che arriva una riga "MEDIA(...)"
 * e letto da ChartActivity per disegnare il grafico.
 */
object ThdHistory {
    private const val MAX_POINTS = 200

    private val thdValues = mutableListOf<Float>()
    private val thdnValues = mutableListOf<Float>()

    @Synchronized
    fun addSample(thd: Float, thdn: Float) {
        thdValues.add(thd)
        thdnValues.add(thdn)
        if (thdValues.size > MAX_POINTS) thdValues.removeAt(0)
        if (thdnValues.size > MAX_POINTS) thdnValues.removeAt(0)
    }

    @Synchronized
    fun snapshot(): Pair<List<Float>, List<Float>> = Pair(thdValues.toList(), thdnValues.toList())

    @Synchronized
    fun clear() {
        thdValues.clear()
        thdnValues.clear()
    }
}
