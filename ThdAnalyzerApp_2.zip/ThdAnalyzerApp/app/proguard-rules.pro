# Nessuna regola particolare necessaria per ora
